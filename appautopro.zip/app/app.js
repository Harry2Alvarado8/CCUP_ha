var applicationModule = require("application");
applicationModule.start({ moduleName: "login/login" });